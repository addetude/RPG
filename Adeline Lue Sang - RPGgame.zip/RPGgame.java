import arc.*;
import java.awt.image.BufferedImage;
import java.awt.Color;
import java.awt.Font;

public class RPGgame{
	public static void main(String [] args){
		Console con = new Console (900,800) ;
		int intKey;
		
		//run all methods in infinate while loop until user closes program
		while(true){
			int Health = 50;
			int intInput = loadMenu(con);
			if(intInput == 1){
				int Map = Map(con);
				reloadMap1(Map);
				String strMap1 [][] = loadMap1(con, Health, Map);
				Health = loadGame(con, strMap1, Health, Map);
				//if more than zero health, win; else, lose
				if(Health <= 0){
					loadEnd(con);
				}else if(Health <= 50){
					loadWin(con);
				}
			}
			//load help menu if help button is pressed
			if(intInput == 2){
				loadHelp(con);
			}
		}

	}
	
	//menu loading method
	public static int loadMenu(Console con){
		
		//initialize variables
		int intInput = 0;
		BufferedImage imgBird = con.loadImage("bird.png");
		BufferedImage imgMenuBackground = con.loadImage("menubackground.png");
		Font FancyFont = con.loadFont("GreatVibes-Regular.ttf", 50);
		Font LargeFont = con.loadFont("EagleLake-Regular.ttf", 100);
		Font SmallFont = con.loadFont("ARCADECLASSIC.ttf", 40);
		
		//while loop to constantly get mouse input
		while(intInput == 0){
			int Mouse = con.currentMouseButton();
			int MouseX = con.currentMouseX();
			int MouseY = con.currentMouseY();
			
			con.drawImage(imgMenuBackground,0,0);
			con.setDrawFont(FancyFont);
			con.setDrawColor(Color.BLACK);
			con.drawString("Welcome to... ", 90, 170);
			con.setDrawFont(LargeFont);
			con.setDrawColor(Color.BLUE);
			con.drawString("Eagle Lake", 155, 180);
			con.setDrawFont(SmallFont);
			con.setDrawColor(Color.BLACK);
			con.drawString("Help", 540, 430);
			con.drawString("Start", 250, 430);
			con.repaint();
			
			//if mouse presses start button, intput is 1
			if(MouseX > 248 && MouseX < 353 && MouseY > 430 && MouseY < 470){
				con.drawImage(imgBird, 150, 410);
				if(Mouse == 1){
					intInput = 1;
				}
				
			//if mouse presses start button, intput is 2
			}if(MouseX > 540 && MouseX < 625 && MouseY > 430 && MouseY < 470){	
				con.drawImage(imgBird, 440, 410);
				if(Mouse == 1){
					intInput = 2;
				}
			}
		}
		return intInput;
	}
	
	//method to read csv map file and print out tile based on letter
	public static String [][] loadMap1(Console con, int Health, int Map){
		
		int intRow;
		int intCol;
		
		String strMap1 [][] = new String [20][20];
	
		BufferedImage imgGrass = con.loadImage("grass.jpg");
		BufferedImage imgTree = con.loadImage("tree.png");
		BufferedImage imgWater1 = con.loadImage("water.png");
		BufferedImage imgWater2 = con.loadImage("water2.png");
		BufferedImage imgBridge = con.loadImage("bridge.png");
		BufferedImage imgBuilding = con.loadImage("building.png");
		BufferedImage imgEnemy0 = con.loadImage("frame_0_delay-0.1s.png");
		BufferedImage imgsidebar1 = con.loadImage("sidebar5.png");
		BufferedImage imgsidebar2 = con.loadImage("sidebar4.png");
		BufferedImage imgsidebar3 = con.loadImage("sidebar3.png");
		BufferedImage imgsidebar4 = con.loadImage("sidebar2.png");
		BufferedImage imgsidebar5 = con.loadImage("sidebar1.png");
		
		TextInputFile txtMap1 = new TextInputFile ("map1.csv");
		
		//use map variable to detect which map user selected
		if(Map == 2){
			txtMap1.close();
			txtMap1 = new TextInputFile ("map2.csv");
		}
		
		//load map from csv into strMap1 array	
		for (intCol = 0; intCol < 20; intCol++){
			String strLine = txtMap1.readLine();
			String strPart [] = strLine.split(",");
			for(intRow = 0; intRow < 20; intRow++){
				strMap1 [intCol][intRow] = strPart [intRow];
			}
		}
		
		//print map tiles based on strMap1 array onto console 
		for (intCol = 0; intCol < 20; intCol++){
			for(intRow = 0; intRow < 20; intRow++){
				if(strMap1[intCol][intRow].equals("x") || strMap1[intCol][intRow].equals("t") || strMap1[intCol][intRow].equals("b") || strMap1[intCol][intRow].equals("e")|| strMap1[intCol][intRow].equals("a")){
					con.drawImage(imgGrass,intRow*40,intCol*40);
				}if(strMap1[intCol][intRow].equals("t") || strMap1[intCol][intRow].equals("a")){
					con.drawImage(imgTree,intRow*40,intCol*40);
				}if(strMap1[intCol][intRow].equals("w")){
					if(intRow%2 == 0 && intCol%2 == 1 || intRow%2 == 1 && intCol%2 == 0){
						con.drawImage(imgWater1,intRow*40,intCol*40);
					}else{
						con.drawImage(imgWater2,intRow*40,intCol*40);
					}
				}if(strMap1[intCol][intRow].equals("y")){
					con.drawImage(imgBridge,intRow*40,intCol*40);
				}if(strMap1[intCol][intRow].equals("b")){
					con.drawImage(imgBuilding,intRow*40,intCol*40);
				}if(strMap1[intCol][intRow].equals("e")){
					con.drawImage(imgEnemy0,intRow*40,intCol*40);
				}
			}
		}
		
		//print health side bar
		con.setDrawColor(Color.WHITE);
		if(Health == 10){
			con.drawImage(imgsidebar1, 800, 0);
		}if(Health == 20){
			con.drawImage(imgsidebar2, 800, 0);
		}if(Health == 30){
			con.drawImage(imgsidebar3, 800, 0);
		}if(Health == 40){
			con.drawImage(imgsidebar4, 800, 0);
		}if(Health == 50){
			con.drawImage(imgsidebar5, 800, 0);
			
		}
		
		con.repaint();
		
		txtMap1.close();
		return strMap1;
	}
	
	//method that runs all major game calculations
	public static int loadGame(Console con, String strMap1 [][], int Health, int Map){
		
		//initialize all variables
		BufferedImage imgHero = con.loadImage("boy.png");
		BufferedImage imgBigHero = con.loadImage("bigavatar.png");
		BufferedImage imgBigEnemy = con.loadImage("bigenemy.png");
		BufferedImage imgBigEnemyHurt = con.loadImage("bigenemyhurt.png");
		BufferedImage imgdeath1 = con.loadImage("death1.png");
		BufferedImage imgdeath2 = con.loadImage("death2.png");
		BufferedImage imgdeath3 = con.loadImage("death3.png");
		BufferedImage imgdeath4 = con.loadImage("death4.png");
		BufferedImage imgdeath5 = con.loadImage("death5.png");
		BufferedImage imgbattlefield = con.loadImage("battlefield1.png");
		BufferedImage imgfireball = con.loadImage("fireball.png");
		BufferedImage imghit = con.loadImage("hit.png");
		BufferedImage imgfireball2 = con.loadImage("reversefireball.png");
		BufferedImage imgfall1 = con.loadImage("enemyfall1.png");
		BufferedImage imgfall2 = con.loadImage("enemyfall2.png");
		BufferedImage imgfall3 = con.loadImage("enemyfall3.png");
		BufferedImage imgfall4 = con.loadImage("enemyfall4.png");
		BufferedImage imgsidebar = con.loadImage("sidebar.png");
		BufferedImage imgsidebar1 = con.loadImage("sidebar5.png");
		BufferedImage imgsidebar2 = con.loadImage("sidebar4.png");
		BufferedImage imgsidebar3 = con.loadImage("sidebar3.png");
		BufferedImage imgsidebar4 = con.loadImage("sidebar2.png");
		BufferedImage imgsidebar5 = con.loadImage("sidebar1.png");
		
		int intCount;
		int intCounter;
		int intKey = -1;
		int intx = 10;
		int inty = 16;
		int i;
		int MouseX;
		int MouseY;
		int Mouse;
		int intEnemies = 0;
		boolean Boost = false;
		
		Font SmallerFont = con.loadFont("ARCADECLASSIC.ttf", 15);
		Font SmallFont = con.loadFont("ARCADECLASSIC.ttf", 40);
		Font BigFont = con.loadFont("ARCADECLASSIC.ttf", 140);
		con.setDrawColor(Color.WHITE);
			
		//count number of enemies on map
		for(intCount = 0; intCount < 20; intCount++){
			for(intCounter = 0; intCounter < 20; intCounter++){
				String strLine = strMap1 [intCount][intCounter];
				if(strLine.equals("e")){
					intEnemies += 1;
				}
			}
		}
		
		//add stats to sidebar
		con.drawImage(imgHero, 400, 640);
		con.setDrawColor(Color.WHITE);
		con.setDrawFont(BigFont);
		con.drawString(""+intEnemies,815,500);
		if(Boost == true){
			con.setDrawColor(Color.WHITE);
			con.setDrawFont(SmallerFont);
			con.drawString("Boost", 828, 680);
			con.drawString("Activated", 813, 700);
		}
		con.repaint();
		
		//if wsad key is pressed, change hero coordinates (as long as tile is not a tree)
		while(true){
			intKey = con.getKey();
			if(intKey == 87 && (inty - 1) >= 0 && !strMap1 [inty-1][intx].equals("t")){
				inty -= 1;
			}if(intKey == 83 && (inty + 1) < 20 && !strMap1 [inty+1][intx].equals("t")){
				inty += 1;
			}if(intKey == 65 && (intx - 1) >= 0 && !strMap1 [inty][intx-1].equals("t")){
				intx -= 1;
			}if(intKey == 68 && (intx + 1) < 20 && !strMap1 [inty][intx+1].equals("t")){
				intx += 1;
			}
			
			//if hero coordinate equals water tile, load drown screen	
			if(strMap1 [inty][intx].equals("w")){
				con.drawImage(imgsidebar, 800, 0);
				con.setDrawFont(BigFont);
				con.setDrawColor(Color.WHITE);
				con.drawString(""+intEnemies,815,500);
				if(Boost == true){
					con.setDrawColor(Color.WHITE);
					con.setDrawFont(SmallerFont);
					con.drawString("Boost", 828, 680);
					con.drawString("Activated", 813, 700);
				}
				con.setDrawFont(SmallFont);
				while(intKey != 80){
					intKey = con.currentKey();
					con.drawImage(imgdeath1,0,0);
					con.setDrawFont(BigFont);
					con.drawString("you died", 110, 220);
					con.setDrawFont(SmallFont);
					con.drawString("ho ld   p   key   to   p lay   again", 140, 370);
					con.repaint();
					con.sleep(150);
					con.drawImage(imgdeath2,0,0);
					con.setDrawFont(BigFont);
					con.drawString("you died", 110, 220);
					con.setDrawFont(SmallFont);
					con.drawString("ho ld   p   key   to   p lay   again", 140, 370);
					con.repaint();
					con.sleep(150);
					con.drawImage(imgdeath3,0,0);
					con.setDrawFont(BigFont);
					con.drawString("you died", 110, 220);
					con.setDrawFont(SmallFont);						
					con.drawString("ho ld   p   key   to   p lay   again", 140, 370);
					con.repaint();
					con.sleep(150);
					con.drawImage(imgdeath4,0,0);
					con.setDrawFont(BigFont);
					con.drawString("you died", 110, 220);
					con.setDrawFont(SmallFont);
					con.drawString("ho ld   p   key   to   p lay   again", 140, 370);
					con.repaint();
					con.sleep(150);
					con.drawImage(imgdeath5,0,0);
					con.setDrawFont(BigFont);
					con.drawString("you died", 110, 220);
					con.setDrawFont(SmallFont);
					con.drawString("ho ld   p   key   to   p lay   again", 140, 370);
					con.repaint();
					con.sleep(150);
				}
				return 150;
			}
			
			//if hero coordinates equal 'a' tile, give them an attack boost that lasts the rest of the game 
			if(strMap1 [inty][intx].equals("a")){
				Boost = true;
				
				con.setDrawColor(Color.WHITE);
				con.setDrawFont(SmallerFont);
				con.drawString("Boost", 828, 680);
				con.drawString("Activated", 813, 700);
				con.repaint();
				
				//replace 'a' tile with grass after hero collects it
				strMap1 [inty][intx] = "x";
				
				TextOutputFile txtMap1 = new TextOutputFile("map1.csv");
				
				if(Map == 2){
					txtMap1.close();
					txtMap1 = new TextOutputFile("map2.csv");
				}
				
				for(intCount = 0; intCount < 20; intCount++){
					for(intCounter = 0; intCounter < 20; intCounter++){
						txtMap1.print(strMap1[intCount][intCounter]+",");
					}
					txtMap1.println("");
				}
				txtMap1.close();
			}
			
			//if hero coordinates equals building tile, add 10 health and replace with grass tile
			if(strMap1 [inty][intx].equals("b")){
				//only works if users health is less than 50
				if(Health < 50){
					strMap1 [inty][intx] = "x";
					Health += 10;
					TextOutputFile txtMap1 = new TextOutputFile("map1.csv");
					
					if(Map == 2){
						txtMap1.close();
						txtMap1 = new TextOutputFile("map2.csv");
					}
					
					for(intCount = 0; intCount < 20; intCount++){
						for(intCounter = 0; intCounter < 20; intCounter++){
							txtMap1.print(strMap1[intCount][intCounter]+",");
						}
						txtMap1.println("");
					}
					txtMap1.close();
				}
				
				//draw sidebar with hero stats
				if(Health == 10){
					con.drawImage(imgsidebar1, 800, 0);
				}if(Health == 20){
					con.drawImage(imgsidebar2, 800, 0);
				}if(Health == 30){
					con.drawImage(imgsidebar3, 800, 0);
				}if(Health == 40){
					con.drawImage(imgsidebar4, 800, 0);
				}if(Health == 50){
					con.drawImage(imgsidebar5, 800, 0);
				}	
				
				con.setDrawColor(Color.WHITE);
				con.setDrawFont(BigFont);
				con.drawString(""+intEnemies,815,500);
				if(Boost == true){
					con.setDrawColor(Color.WHITE);
					con.setDrawFont(SmallerFont);
					con.drawString("Boost", 828, 680);
					con.drawString("Activated", 813, 700);
				}
				con.repaint();
				
			}
			
			//if hero coordinates equals an enemy, load battle engine
			if(strMap1 [inty][intx].equals("e")){
				int intLevel = Random(17,8);
				int intDefeat = 0;
				
				//generate random enemy level
				con.setDrawColor(Color.BLACK);
				con.setDrawFont(SmallFont);
				con.drawRect(800, 0, 200, 800);
				con.drawImage(imgbattlefield,0,0);
				con.drawImage(imgBigHero, 20, 300);
				con.drawImage(imgBigEnemy, 500, 250);
				con.setDrawColor(Color.RED);
				con.drawString(""+(300 - intDefeat*100), 618, 200);
				con.setDrawColor(Color.BLACK);
				con.drawString(""+Health, 130, 260); 
				con.setDrawColor(Color.WHITE);
				con.fillRoundRect(305, 90, 180, 75, 50, 50); 
				con.setDrawColor(Color.BLACK);
				con.drawString("Level "+(intLevel-7), 325, 100);
				con.repaint();
				con.sleep(3000);
				
				//enemy must be hit three times, shooting 5 fireballs in between
				while(intDefeat < 3 && Health > 0){
					for(i = 0; i < 5; i++){
						int intRand = Random(450, 250);
						for(intCount = 500; intCount > 120; intCount -= intLevel){
							con.drawImage(imgbattlefield,0,0);
							con.drawImage(imgBigHero, 20, 300);
							con.drawImage(imgBigEnemy, 500, 250);
							con.drawImage(imgfireball, intCount, intRand);
							con.setDrawColor(Color.RED);
							con.drawString(""+(300 - intDefeat*100), 618, 200);
							con.setDrawColor(Color.BLACK);
							con.drawString(""+Health, 130, 260); 
							con.repaint();
							Mouse = con.currentMouseButton();
							MouseX = con.currentMouseX();
							MouseY = con.currentMouseY();
							con.sleep(10);
							//fireball disappears if user clicks fireball
							if(Mouse == 1 && MouseX > intCount && MouseX < intCount + 100 && MouseY > intRand && MouseY < intRand + 100){
								break;
							//if fireball hits user, draw hit image and subtract 10 health
							}if(intCount <= 135){
								Health -= 10;
								con.drawImage(imghit, 50, intRand - 50);
								con.repaint();
								con.sleep(1000);
								break;
							}
						}
						
						//print hero stats onto sidebar
						if(Health <= 0){
							con.drawImage(imgsidebar, 800, 0);
							con.setDrawColor(Color.WHITE);
							con.setDrawFont(BigFont);
							con.drawString(""+intEnemies,815,500);
							if(Boost == true){
								con.setDrawColor(Color.WHITE);
								con.setDrawFont(SmallerFont);
								con.drawString("Boost", 828, 680);
								con.drawString("Activated", 813, 700);
							}
							con.repaint();
							con.setDrawFont(SmallFont);
							break;
						}
						
						con.setDrawColor(Color.WHITE);
						
						if(Health == 10){
							con.drawImage(imgsidebar1, 800, 0);
						}if(Health == 20){
							con.drawImage(imgsidebar2, 800, 0);
						}if(Health == 30){
							con.drawImage(imgsidebar3, 800, 0);
						}if(Health == 40){
							con.drawImage(imgsidebar4, 800, 0);
						}if(Health == 50){
							con.drawImage(imgsidebar5, 800, 0);
						}
						
						con.setDrawColor(Color.WHITE);
						con.setDrawFont(BigFont);
						con.drawString(""+intEnemies,815,500);
						if(Boost == true){
							con.setDrawColor(Color.WHITE);
							con.setDrawFont(SmallerFont);
							con.drawString("Boost", 828, 680);
							con.drawString("Activated", 813, 700);
						}
						con.repaint();
						con.setDrawFont(SmallFont);
						
					}
					
					//if hero has 0 health, return to main
					if(Health == 0){
						con.drawImage(imgbattlefield,0,0);
						con.drawImage(imgBigHero, 20, 300);
						con.drawImage(imgBigEnemy, 500, 250);
						con.setDrawColor(Color.RED);
						con.drawString(""+(300 - intDefeat*100), 618, 200);
						con.setDrawColor(Color.BLACK);
						con.drawString(""+Health, 130, 260);
						con.setDrawColor(Color.WHITE);
						con.fillRoundRect(305, 90, 200, 75, 50, 50); 
						con.setDrawColor(Color.BLACK);
						con.drawString("You  Lose!", 315, 100);
						con.repaint();
						con.sleep(5000);
						break;
					}
					
					//randomly select attack key
					int intAttack = 0;
					int intRand = Random(4,1);
					String strKey = " ";
					if(intRand == 4){
						strKey = "a";
						intAttack = 65;
					}if(intRand == 1){
						strKey = "d";
						intAttack = 68;
					}if(intRand == 2){
						strKey = "s";
						intAttack = 83;
					}if(intRand == 3){
						strKey = "w";
						intAttack = 87;
					}
					
					//if correct attack key is pressed, hero shoots at enemy
					con.drawImage(imgbattlefield,0,0);
					con.drawImage(imgBigHero, 20, 300);
					con.drawImage(imgBigEnemy, 500, 250);
					con.setDrawColor(Color.RED);
					con.drawString(""+(300 - intDefeat*100), 618, 200);
					con.setDrawColor(Color.BLACK);
					con.drawString(""+Health, 130, 260); 
					con.setDrawColor(Color.WHITE);
					con.fillRoundRect(215, 90, 385, 75, 50, 50); 
					con.setDrawColor(Color.BLACK);
					con.drawString("ho ld  "+strKey+"  to  attack!", 240, 100);
					con.repaint();
					con.sleep(2000);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					intKey = con.currentKey () ; 
					con.sleep(25);
					
					if(intKey == intAttack){
						
						// hero jump animation
						con.drawImage(imgbattlefield,0,0);
						con.drawImage(imgBigHero, 20, 295);
						con.drawImage(imgBigEnemy, 500, 250);
						con.setDrawColor(Color.RED);
						con.drawString(""+(300 - intDefeat*100), 618, 200);
						con.setDrawColor(Color.BLACK);
						con.drawString(""+Health, 130, 260); 
						con.repaint();
						con.sleep(20);
						con.drawImage(imgbattlefield,0,0);
						con.drawImage(imgBigHero, 20, 290);
						con.drawImage(imgBigEnemy, 500, 250);
						con.setDrawColor(Color.RED);
						con.drawString(""+(300 - intDefeat*100), 618, 200);
						con.setDrawColor(Color.BLACK);
						con.drawString(""+Health, 130, 260); 
						con.repaint();
						con.sleep(20);
						con.drawImage(imgbattlefield,0,0);
						con.drawImage(imgBigHero, 20, 285);
						con.drawImage(imgBigEnemy, 500, 250);
						con.setDrawColor(Color.RED);
						con.drawString(""+(300 - intDefeat*100), 618, 200);
						con.setDrawColor(Color.BLACK);
						con.drawString(""+Health, 130, 260);
						con.repaint();
						con.sleep(20);
						con.drawImage(imgbattlefield,0,0);
						con.drawImage(imgBigHero, 20, 290);
						con.drawImage(imgBigEnemy, 500, 250);
						con.setDrawColor(Color.RED);
						con.drawString(""+(300 - intDefeat*100), 618, 200);
						con.setDrawColor(Color.BLACK);
						con.drawString(""+Health, 130, 260);
						con.repaint();
						con.sleep(20);
						con.drawImage(imgbattlefield,0,0);
						con.drawImage(imgBigHero, 20, 295);
						con.drawImage(imgBigEnemy, 500, 250);
						con.setDrawColor(Color.RED);
						con.drawString(""+(300 - intDefeat*100), 618, 200);
						con.setDrawColor(Color.BLACK);
						con.drawString(""+Health, 130, 260);
						con.repaint();
						con.sleep(20);
						
						for(intCount = 120; intCount <= 500; intCount += 10){
							con.drawImage(imgbattlefield,0,0);
							con.drawImage(imgBigHero, 20, 300);
							con.drawImage(imgBigEnemy, 500, 250);
							con.setDrawColor(Color.RED);
							con.drawString(""+(300 - intDefeat*100), 618, 200);
							con.setDrawColor(Color.BLACK);
							con.drawString(""+Health, 130, 260);
							con.setDrawColor(Color.WHITE);
							con.fillRoundRect(350, 90, 105, 75, 50, 50); 
							con.setDrawColor(Color.BLACK);
							con.drawString("Hit!", 365, 100);
							con.drawImage(imgfireball2, intCount, 350);
							con.repaint();
							con.sleep(10);
						}
						
						//if hero is boosted, one hit will be equivalent to 3 hits
						if(Boost == true){
							intDefeat = 3;
						}
						
						con.drawImage(imgbattlefield,0,0);
						con.drawImage(imgBigHero, 20, 300);
						con.drawImage(imgBigEnemyHurt, 500, 250);
						con.drawImage(imghit, 550, 325);
						con.setDrawColor(Color.RED);
						con.drawString(""+(300 - intDefeat*100), 618, 200);
						con.setDrawColor(Color.BLACK);
						con.drawString(""+Health, 130, 260);
						con.repaint();
						con.sleep(300);
						
						//if enemy is hit 3 times, enemy dies
						if(intDefeat < 2){
							intDefeat += 1;
							con.drawImage(imgbattlefield,0,0);
							con.drawImage(imgBigHero, 20, 300);
							con.drawImage(imgBigEnemyHurt, 500, 250);
							con.setDrawColor(Color.RED);
							con.drawString(""+(300 - intDefeat*100), 618, 200);
							con.setDrawColor(Color.BLACK);
							con.drawString(""+Health, 130, 260);
							con.repaint();
							con.sleep(3000);
						}else{
							intDefeat += 1;
							if(intDefeat > 3){
								intDefeat = 3;
							}
							
							con.drawImage(imgbattlefield,0,0);
							con.drawImage(imgBigHero, 20, 300);
							con.drawImage(imgfall2, 500, 350);
							con.setDrawColor(Color.RED);
							con.drawString(""+(300 - intDefeat*100), 618, 200);
							con.setDrawColor(Color.BLACK);
							con.drawString(""+Health, 130, 260);
							con.repaint();
							con.sleep(25);
							con.drawImage(imgbattlefield,0,0);
							con.drawImage(imgBigHero, 20, 300);
							con.drawImage(imgfall3, 500, 350);
							con.setDrawColor(Color.RED);
							con.drawString(""+(300 - intDefeat*100), 618, 200);
							con.setDrawColor(Color.BLACK);
							con.drawString(""+Health, 130, 260);
							con.repaint();
							con.sleep(25);
							con.drawImage(imgbattlefield,0,0);
							con.drawImage(imgBigHero, 20, 300);
							con.drawImage(imgfall4, 500, 350);
							con.setDrawColor(Color.RED);
							con.drawString(""+(300 - intDefeat*100), 618, 200);
							con.setDrawColor(Color.BLACK);
							con.drawString(""+Health, 130, 260);
							con.repaint();
							con.sleep(3000);
						}
					
					//if hero does not press correct key, miss
					}else{
						con.drawImage(imgbattlefield,0,0);
						con.drawImage(imgBigHero, 20, 300);
						con.drawImage(imgBigEnemy, 500, 250);
						con.setDrawColor(Color.RED);
						con.drawString(""+(300 - intDefeat*100), 618, 200);
						con.setDrawColor(Color.BLACK);
						con.drawString(""+Health, 130, 260);
						con.setDrawColor(Color.WHITE);
						con.fillRoundRect(325, 90, 120, 75, 50, 50); 
						con.setDrawColor(Color.BLACK);
						con.drawString("Miss!", 335, 100);
						con.repaint();
						con.sleep(3000);
					}	
				}
				
				//return to main if hero has 0 health
				if(Health == 0){
					return Health;
				}else{
					con.setDrawFont(SmallFont);
					
					// hero jump animation + you win text
					con.drawImage(imgbattlefield,0,0);
					con.drawImage(imgBigHero, 20, 295);
					con.drawImage(imgfall4, 500, 350);
					con.setDrawColor(Color.RED);
					con.drawString(""+(300 - intDefeat*100), 618, 200);
					con.setDrawColor(Color.BLACK);
					con.drawString(""+Health, 130, 260);
					con.repaint();
					con.sleep(20);
					con.drawImage(imgbattlefield,0,0);
					con.drawImage(imgBigHero, 20, 290);
					con.drawImage(imgfall4, 500, 350);
					con.setDrawColor(Color.RED);
					con.drawString(""+(300 - intDefeat*100), 618, 200);
					con.setDrawColor(Color.BLACK);
					con.drawString(""+Health, 130, 260);
					con.repaint();
					con.sleep(20);
					con.drawImage(imgbattlefield,0,0);
					con.drawImage(imgBigHero, 20, 285);
					con.drawImage(imgfall4, 500, 350);
					con.setDrawColor(Color.RED);
					con.drawString(""+(300 - intDefeat*100), 618, 200);
					con.setDrawColor(Color.BLACK);
					con.drawString(""+Health, 130, 260);
					con.repaint();
					con.sleep(20);
					con.drawImage(imgbattlefield,0,0);
					con.drawImage(imgBigHero, 20, 290);
					con.drawImage(imgfall4, 500, 350);
					con.setDrawColor(Color.RED);
					con.drawString(""+(300 - intDefeat*100), 618, 200);
					con.setDrawColor(Color.BLACK);
					con.drawString(""+Health, 130, 260);
					con.repaint();
					con.sleep(20);
					con.drawImage(imgbattlefield,0,0);
					con.drawImage(imgBigHero, 20, 295);
					con.drawImage(imgfall4, 500, 350);
					con.setDrawColor(Color.RED);
					con.drawString(""+(300 - intDefeat*100), 618, 200);
					con.setDrawColor(Color.BLACK);
					con.drawString(""+Health, 130, 260);
					con.repaint();
					con.sleep(20);
					con.drawImage(imgbattlefield,0,0);
					con.drawImage(imgBigHero, 20, 300);
					con.drawImage(imgfall4, 500, 350);
					con.setDrawColor(Color.RED);
					con.drawString(""+(300 - intDefeat*100), 618, 200);
					con.setDrawColor(Color.BLACK);
					con.drawString(""+Health, 130, 260);
					con.setDrawColor(Color.WHITE);
					con.fillRoundRect(310, 90, 200, 75, 50, 50); 
					con.setDrawColor(Color.BLACK);
					con.drawString("You Win!", 335, 100);
					con.repaint();
					con.sleep(3000);
					
					//if hero wins, reprint enemy tile with grass tile
					TextOutputFile txtMap1 = new TextOutputFile ("map1.csv");
					
					if(Map == 2){
						txtMap1.close();
						txtMap1 = new TextOutputFile("map2.csv");
					}
					
					strMap1 [inty][intx] = "x";
					
					for(intCount = 0; intCount < 20; intCount++){
						for(intCounter = 0; intCounter < 20; intCounter++){
							txtMap1.print(strMap1[intCount][intCounter]+",");
						}
						txtMap1.println("");
					}
					txtMap1.close();
					
					//print sidebar with hero stats
					if(Health == 10){
						con.drawImage(imgsidebar1, 800, 0);
					}if(Health == 20){
						con.drawImage(imgsidebar2, 800, 0);
					}if(Health == 30){
						con.drawImage(imgsidebar3, 800, 0);
					}if(Health == 40){
						con.drawImage(imgsidebar4, 800, 0);
					}if(Health == 50){
						con.drawImage(imgsidebar5, 800, 0);
					}
					
					//enemy counter subtracts 1
					intEnemies -= 1;
					
					if(Boost == true){
						con.setDrawColor(Color.WHITE);
						con.setDrawFont(SmallerFont);
						con.drawString("Boost", 828, 680);
						con.drawString("Activated", 813, 700);
					}	
					
					con.setDrawFont(BigFont);
					con.drawString(""+intEnemies,815,500);
					con.repaint();
					
					//if no heros left, return to main
					if(intEnemies == 0){
						return Health;
					}
					
					
				}
			}
			
			//reload new map with one less enemy
			loadMap1(con, Health, Map);
			
			//print stats onto sidebar
			con.setDrawColor(Color.WHITE);
			con.setDrawFont(BigFont);
			con.drawString(""+intEnemies,815,500);
			if(Boost == true){
				con.setDrawColor(Color.WHITE);
				con.setDrawFont(SmallerFont);
				con.drawString("Boost", 828, 680);
				con.drawString("Activated", 813, 700);
			}
			con.drawImage(imgHero, intx*40, inty*40);				
			con.repaint();
		}					

	}
	
	//method for death by enemy
	public static void loadEnd(Console con){
		BufferedImage imgenemy1 = con.loadImage("frame_0_delay-0.1s (1).png");
		BufferedImage imgenemy2 = con.loadImage("frame_1_delay-0.1s (1).png");
		BufferedImage imgenemy3 = con.loadImage("frame_2_delay-0.1s (1).png");
		BufferedImage imgenemy4 = con.loadImage("frame_3_delay-0.1s (1).png");
		BufferedImage imgenemy5 = con.loadImage("frame_4_delay-0.1s (1).png");
		BufferedImage imgenemy6 = con.loadImage("frame_5_delay-0.1s (1).png");
		BufferedImage imgenemy7 = con.loadImage("frame_6_delay-0.1s (1).png");
		BufferedImage imgenemy8 = con.loadImage("frame_7_delay-0.1s (1).png");
		BufferedImage imgenemy9 = con.loadImage("frame_8_delay-0.1s (1).png");
		BufferedImage imgsidebar = con.loadImage("sidebar-1.png");
		
		Font BigFont = con.loadFont("ARCADECLASSIC.ttf", 100);
		Font SmallFont = con.loadFont("ARCADECLASSIC.ttf", 40);
		
		con.drawImage(imgsidebar, 800, 0);
		con.setDrawColor(Color.WHITE);
		
		int intKey = 0;
		
		//death screen animation
		while(intKey != 80){
			intKey = con.currentKey();
			con.setDrawColor(Color.BLACK);
			con.fillRect(0,0,800,800);
			con.setDrawColor(Color.WHITE);
			con.drawImage(imgenemy1, -100, 150);
			con.setDrawFont(BigFont);
			con.drawString("Game Over", 320, 300);
			con.setDrawFont(SmallFont);
			con.drawString("Ho ld  p  to  p lay  again", 345, 400);
			con.repaint();
			con.sleep(100);
			con.setDrawColor(Color.BLACK);
			con.fillRect(0,0,800,800);
			con.setDrawColor(Color.WHITE);
			con.drawImage(imgenemy2, -100, 150);
			con.setDrawFont(BigFont);
			con.drawString("Game Over", 320, 300);
			con.setDrawFont(SmallFont);
			con.drawString("Ho ld  p  to  p lay  again", 345, 400);
			con.repaint();
			con.sleep(100);
			con.setDrawColor(Color.BLACK);
			con.fillRect(0,0,800,800);
			con.setDrawColor(Color.WHITE);
			con.drawImage(imgenemy3, -100, 150);
			con.setDrawFont(BigFont);
			con.drawString("Game Over", 320, 300);
			con.setDrawFont(SmallFont);
			con.drawString("Ho ld  p  to  p lay  again", 345, 400);
			con.repaint();
			con.sleep(100);
			intKey = con.currentKey();
			con.setDrawColor(Color.BLACK);
			con.fillRect(0,0,800,800);
			con.setDrawColor(Color.WHITE);
			con.drawImage(imgenemy4, -100, 150);
			con.setDrawFont(BigFont);
			con.drawString("Game Over", 320, 300);
			con.setDrawFont(SmallFont);
			con.drawString("Ho ld  p  to  p lay  again", 345, 400);
			con.repaint();
			con.sleep(100);
			con.setDrawColor(Color.BLACK);
			con.fillRect(0,0,800,800);
			con.setDrawColor(Color.WHITE);
			con.drawImage(imgenemy5, -100, 150);
			con.setDrawFont(BigFont);
			con.drawString("Game Over", 320, 300);
			con.setDrawFont(SmallFont);
			con.drawString("Ho ld  p  to  p lay  again", 345, 400);
			con.repaint();
			con.sleep(100);
			intKey = con.currentKey();
			con.setDrawColor(Color.BLACK);
			con.fillRect(0,0,800,800);
			con.setDrawColor(Color.WHITE);
			con.drawImage(imgenemy6, -100, 150);
			con.setDrawFont(BigFont);
			con.drawString("Game Over", 320, 300);
			con.setDrawFont(SmallFont);
			con.drawString("Ho ld  p  to  p lay  again", 345, 400);
			con.repaint();
			con.sleep(100);
			con.setDrawColor(Color.BLACK);
			con.fillRect(0,0,800,800);
			con.setDrawColor(Color.WHITE);
			con.drawImage(imgenemy7, -100, 150);
			con.setDrawFont(BigFont);
			con.drawString("Game Over", 320, 300);
			con.setDrawFont(SmallFont);
			con.drawString("Ho ld  p  to  p lay  again", 345, 400);
			con.repaint();
			con.sleep(100);
			intKey = con.currentKey();
			con.setDrawColor(Color.BLACK);
			con.fillRect(0,0,800,800);
			con.setDrawColor(Color.WHITE);
			con.drawImage(imgenemy8, -100, 150);
			con.setDrawFont(BigFont);
			con.drawString("Game Over", 320, 300);
			con.setDrawFont(SmallFont);
			con.drawString("Ho ld  p  to  p lay  again", 345, 400);
			con.repaint();
			con.sleep(100);
			con.setDrawColor(Color.BLACK);
			con.fillRect(0,0,800,800);
			con.setDrawColor(Color.WHITE);
			con.drawImage(imgenemy9, -100, 150);
			con.setDrawFont(BigFont);
			con.drawString("Game Over", 320, 300);
			con.setDrawFont(SmallFont);
			con.drawString("Ho ld  p  to  p lay  again", 345, 400);
			con.repaint();
			con.sleep(100);
		}
		
	}
	
	//load help menu method
	public static void loadHelp(Console con){
		BufferedImage imgHelp1 = con.loadImage("1.png");
		BufferedImage imgHelp2 = con.loadImage("2.png");
		BufferedImage imgHelp3 = con.loadImage("3.png");
		BufferedImage imgHelp4 = con.loadImage("4.png");
		int intPage = 1;
		
		con.setDrawColor(Color.BLACK);
		con.fillRect(800,0,100,800);
		con.repaint();
		
		//keep looping for mouse input
		while(true){
			int MouseX = con.currentMouseX();
			int MouseY = con.currentMouseY();
			int Mouse = con.currentMouseButton();
			
			//sense which buttons are pressed on the menu and load pages accordingly
			if(intPage == 1){
				con.drawImage(imgHelp1, 0, 0);
				con.repaint();
			}if(MouseX > 733 && MouseX < 775 && MouseY > 680 && MouseY < 720 && Mouse == 1 && intPage == 1){
				intPage = 2;
				con.drawImage(imgHelp2, 0, 0);
				con.repaint();
				con.sleep(200);
				Mouse = con.currentMouseButton();
			}if(MouseX > 20 && MouseX < 80 && MouseY > 680 && MouseY < 720 && Mouse == 1 && intPage == 2){
				intPage = 1;
			}if(MouseX > 733 && MouseX < 775 && MouseY > 680 && MouseY < 720 && Mouse == 1 && intPage == 2){
				intPage = 3;
				con.drawImage(imgHelp3, 0, 0);
				con.repaint();
				con.sleep(200);
				Mouse = con.currentMouseButton();
			}if(MouseX > 20 && MouseX < 80 && MouseY > 680 && MouseY < 720 && Mouse == 1 && intPage == 3){
				intPage = 2;
				con.drawImage(imgHelp2, 0, 0);
				con.repaint();
				con.sleep(200);
				Mouse = con.currentMouseButton();
			}if(MouseX > 733 && MouseX < 775 && MouseY > 680 && MouseY < 720 && Mouse == 1 && intPage == 3){
				intPage = 4;
				con.drawImage(imgHelp4, 0, 0);
				con.repaint();
				con.sleep(200);
				Mouse = con.currentMouseButton();
			}if(MouseX > 20 && MouseX < 80 && MouseY > 680 && MouseY < 720 && Mouse == 1 && intPage == 4){
				intPage = 3;
				con.drawImage(imgHelp3, 0, 0);
				con.repaint();
				con.sleep(200);
				Mouse = con.currentMouseButton();
			}if(MouseX > 20 && MouseX < 80 && MouseY > 20 && MouseY < 60 && Mouse == 1){
				return;
			}
		}
	}
	
	//method to reload map after each game; print from hardcopy csv onto main map csv
	public static void reloadMap1(int Map){
		int intCount;
	
		TextInputFile txthardcopy = new TextInputFile("map1hardcopy.csv");
		TextOutputFile txtMap1 = new TextOutputFile("map1.csv");
		
		if(Map == 2){
			txthardcopy.close();
			txtMap1.close();
			txthardcopy = new TextInputFile("map2hardcopy.csv");
			txtMap1 = new TextOutputFile("map2.csv");
		}
		
		for(intCount = 0; intCount < 20; intCount++){
			String strLine = txthardcopy.readLine () ;
			txtMap1.println(strLine);
		}
		
		txthardcopy.close();
		txtMap1.close();
	}
	
	//method to load win screen when all enemies are defeated
	public static void loadWin(Console con){
		
		int intKey = 0;
		
		BufferedImage imghome1 = con.loadImage("home1.png");
		BufferedImage imghome2 = con.loadImage("home2.png");
		BufferedImage imghome3 = con.loadImage("home3.png");
		BufferedImage imghome4 = con.loadImage("home4.png");
		BufferedImage imghome5 = con.loadImage("home5.png");
		BufferedImage imghome6 = con.loadImage("home6.png");
		
		Font BigFont = con.loadFont("ARCADECLASSIC.ttf", 140);
		Font SmallFont = con.loadFont("ARCADECLASSIC.ttf", 50);
		con.setDrawColor(Color.BLACK);
		
		//win animation
		while(intKey != 80){
			intKey = con.currentKey();
			con.drawImage(imghome1,0,0);
			con.setDrawFont(BigFont);
			con.drawString("you won", 150, 120);
			con.setDrawFont(SmallFont);
			con.drawString("ho ld   p   key   to   p lay   again", 80, 260);
			con.repaint();
			con.sleep(150);
			con.drawImage(imghome2,0,0);
			con.setDrawFont(BigFont);
			con.drawString("you won", 150, 120);
			con.setDrawFont(SmallFont);
			con.drawString("ho ld   p   key   to   p lay   again", 80, 260);
			con.repaint();
			con.sleep(150);
			con.drawImage(imghome3,0,0);
			con.setDrawFont(BigFont);
			con.drawString("you won", 150, 120);
			con.setDrawFont(SmallFont);						
			con.drawString("ho ld   p   key   to   p lay   again", 80, 260);
			con.repaint();
			con.sleep(150);
			con.drawImage(imghome4,0,0);		
			con.setDrawFont(BigFont);
			con.drawString("you won", 150, 120);
			con.setDrawFont(SmallFont);
			con.drawString("ho ld   p   key   to   p lay   again", 80, 260);
			con.repaint();
			con.sleep(150);
			con.drawImage(imghome5,0,0);
			con.setDrawFont(BigFont);
			con.drawString("you won", 150, 120);
			con.setDrawFont(SmallFont);
			con.drawString("ho ld   p   key   to   p lay   again", 80, 260);
			con.repaint();
			con.sleep(150);
			con.drawImage(imghome6,0,0);
			con.setDrawFont(BigFont);
			con.drawString("you won", 150, 120);
			con.setDrawFont(SmallFont);
			con.drawString("ho ld   p   key   to   p lay   again", 80, 260);
			con.repaint();
			con.sleep(150);
		}
	}
	
	//method for user to select perfered map
	public static int Map(Console con){
		
		BufferedImage imgMap0 = con.loadImage("mapselect1.png");
		BufferedImage imgMap1 = con.loadImage("mapselect2.png");
		BufferedImage imgMap2 = con.loadImage("mapselect3.png");
			
		int intInput = 0;
			
		while(intInput != 1 || intInput != 2){
			
			con.drawImage(imgMap0,0,0);
			con.repaint();
			
			int MouseX = con.currentMouseX();
			int MouseY = con.currentMouseY();
			int Mouse = con.currentMouseButton();
			
			//check which map button is pressed
			if(MouseX > 155 && MouseX < 740 && MouseY > 290 && MouseY < 430 && Mouse == 1){
				intInput = 1;
				con.drawImage(imgMap2,0,0);
				con.repaint();
				con.sleep(100);
				break;
			}if(MouseX > 155 && MouseX < 740 && MouseY > 500 && MouseY < 640 && Mouse == 1){
				intInput = 2;
				con.drawImage(imgMap1,0,0);
				con.repaint();
				con.sleep(100);
				break;
			} 
		}	
		
		return intInput;
	}	
	
	//method to randomly generate a number
	public static int Random(int intmax, int intmin){
		int Random = (int)(Math.random()*(intmax-intmin)+intmin);
		return Random;
	}
		
}


